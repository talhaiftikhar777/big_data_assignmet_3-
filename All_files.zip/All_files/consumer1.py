
from kafka import KafkaConsumer
import json
from collections import defaultdict
from itertools import combinations
from pymongo import MongoClient

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client['Apriori_result']
collection = db['consumer1_result']

def extract_items(data):
    items = set()
   
    for key in ['description','category', 'title']: # items which we need for finding simliarity 
        if key in data:
            if isinstance(data[key], list):
                items.update(data[key])
            else:
                items.add(data[key])
    return items

def generating_candidate_item_sets(frequent_itemsets, k):
    candidate_set = set()
    for item_set1 in frequent_itemsets:
        for item_set2 in frequent_itemsets:
            result_set = item_set1.union(item_set2)
            if len(result_set) == k:
                candidate_set.add(result_set)
    return candidate_set

def support_count(transactions,  canditates_sets):
    count = defaultdict(int)
    for transaction in transactions:
        for candidate_set in  canditates_sets:
            if candidate_set.issubset(transaction):
                count[candidate_set] += 1
    return count

def Apriori(transactions, min_support):
 
    frequent_itemset = [frozenset([item]) for item in set.union(*transactions)]
    k = 2
    # Apriori algo
    while frequent_itemset:
        # Generate candidate itemsets
        candidates = generating_candidate_item_sets(frequent_itemset, k)
        
        # Count support for candidates
        candidate_counts = support_count(transactions, candidates)

        # Prune candidates that do not meet minimum support
        frequent_itemset = [itemset for itemset, support in candidate_counts.items() if support >= min_support]
        
        # Print frequent itemsets and their support
        print("The frequent item set are ",f"Frequent {k}-itemsets:")
        for itemset, support in candidate_counts.items():
            print(f"{itemset}: {support}")

        k += 1

if __name__ == "__main__":
    topic = "topic1"
    consumer1 = KafkaConsumer(topic, bootstrap_servers=['localhost:9092'])
    
    transactions = []
    
    for message in consumer1:
        data = json.loads(message.value.decode('utf-8'))
        print("Consumer1 Apriori receiving data from topic1:", message.topic)
        print("Data:", data)
        
        
        items = extract_items(data) # function for items collection 
        transactions.append(items)  # appending 
        
        # Apply Apriori 
        min_support = 3  # min support 
        Apriori(transactions, min_support)

# Close MongoDB connection
client.close()

