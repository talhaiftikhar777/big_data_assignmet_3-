from kafka import KafkaConsumer
import json
from collections import defaultdict
from itertools import combinations
from pymongo import MongoClient

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client['son_results']
collection = db['consumer3_results']

class SON:
    def __init__(self, min_support):
        self.min_support = min_support
        self.itemsets = defaultdict(int)

    def extract_items(self, data):
        items = set()
        for key in ['description','category', 'title']:
            if key in data:
                if isinstance(data[key], list):
                    items.update(data[key])
                else:
                    items.add(data[key])
        return items

    def generate_candidates(self, transactions, size):
        candidates = set()
        for transaction in transactions:
            candidates.update(combinations(transaction, size))
        return candidates

    def count_candidates(self, candidates, transactions):
        counts = defaultdict(int)
        for candidate in candidates:
            for transaction in transactions:
                if set(candidate).issubset(transaction):
                    counts[candidate] += 1
        return counts

    def prune_candidates(self, counts):
        return {itemset: support for itemset, support in counts.items() if support >= self.min_support}

    def find_frequent_itemsets(self, transactions):
        transaction_count = len(transactions)
        itemset_size = 1
        while True:
            candidates = self.generate_candidates(transactions, itemset_size)
            if not candidates:
                break
            counts = self.count_candidates(candidates, transactions)
            frequent_itemsets = self.prune_candidates(counts)
            self.itemsets.update(frequent_itemsets)
            if not frequent_itemsets:
                break
            itemset_size += 1

    def print_frequent_itemsets(self):
        print("Frequent itemsets:")
        for itemset, support in self.itemsets.items():
            print(f"{itemset}: {support}")
            
        # Insert results into MongoDB
        for itemset, support in self.itemsets.items():
            collection.insert_one({'itemset': list(itemset), 'support': support})

if __name__ == "__main__":
    topic = "topic1"
    consumer = KafkaConsumer(topic, bootstrap_servers=['localhost:9092'])

    son = SON(min_support=3)
    transactions = []

    for message in consumer:
        data = json.loads(message.value.decode('utf-8'))
        print("Consumer3 SON receiving data from topic1:", message.topic)
        print("Data:", data)

        items = son.extract_items(data)
        transactions.append(items)

    son.find_frequent_itemsets(transactions)
    son.print_frequent_itemsets()

# Close MongoDB connection
client.close()
