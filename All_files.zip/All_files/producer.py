

import json
import time
from kafka import KafkaProducer
from pymongo import MongoClient    # mongo client for connection with mongo db 

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client['producer_logs']
collection = db['data_stream']

def json_file_reding(file_path):
    with open(file_path, 'r') as file:
        data = json.load(file)
    return data


def streaming_data_function(data, topic):
    producer = KafkaProducer(bootstrap_servers=['localhost:9092'])
    for item in data:                          
        producer.send(topic, json.dumps(item).encode('utf-8'))# it sends each item to Kafka topic after converting it to JSON format and encoding it as UTF-8
        collection.insert_one(item)  # Log data to MongoDB
        time.sleep(1)  # the delay of 1 sec for simulating real-time streaming
    producer.close()

if __name__ == "__main__":
    path = "newfile.json"
    # in this file we already have filtered the data so we donot need any further more columns to keep 
    topic = "topic1"
    data = json_file_reding(path)
    streaming_data_function(data, topic)

# Close MongoDB connection
client.close()

