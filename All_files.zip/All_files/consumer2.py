

from kafka import KafkaConsumer
import json
from collections import defaultdict
from itertools import combinations
from pymongo import MongoClient

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client['pcy_results']
collection = db['consumer2_results']

def extract_items(data):
    items = []
    for key, value in data.items():
        if isinstance(value, list):
            items.extend(value)
        elif isinstance(value, str):
            items.append(value)
    return items

def count_item_pairs(transaction_list, hash_buckets, bucket_count):
    counts = defaultdict(int)
    for transaction in transaction_list:
        for pair in combinations(transaction, 2):
            hash_value = hash(tuple(pair)) % bucket_count   # here creating tuples 
            if hash_buckets[hash_value] > 0:
                counts[pair] += 1
    return counts

def filter_candidates(candidate_counts, min_support_threshold):
    return {pair: count for pair, count in candidate_counts.items() if count >= min_support_threshold}

def pcy(transaction_list, min_support_threshold, bucket_size):
    #  Counting  individual items and filter frequent items
    single_counts = defaultdict(int)
    for transaction in transaction_list:
        for item in transaction:
            single_counts[item] += 1
    frequent_items = set(item for item, count in single_counts.items() if count >= min_support_threshold)
    
    #  Initializing hash table
    hash_buckets = [0] * bucket_size
    
    #  Counting item pairs and filter frequent pairs
    candidate_counts = count_item_pairs(transaction_list, hash_buckets, bucket_size)
    frequent_pairs = filter_candidates(candidate_counts, min_support_threshold)
    
    
    print("The Frequent item pairs:")
    for pair, count in frequent_pairs.items():
        print(f"{pair}: {count}")

if __name__ == "__main__":
    topic = "topic1"
    consumer = KafkaConsumer(topic, bootstrap_servers=['localhost:9092'])
    
    transaction_list = []
    
    for message in consumer:
        data = json.loads(message.value.decode('utf-8'))
        print("Consumer2 PCY receiving data from topic1:", message.topic)
        print("Data:", data)
        
       #extraction and appending 
        items = extract_items(data)
        transaction_list.append(set(items))
        
        # Performing PCY algo
        min_support_threshold = 3  # min threshold to 3
        bucket_size = 1000  # Adjusting size 
        pcy(transaction_list, min_support_threshold, bucket_size)

# Close MongoDB connection
client.close()

