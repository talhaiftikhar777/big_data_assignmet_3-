from kafka import KafkaConsumer

def consume_data(topic):
    consumer = KafkaConsumer(topic, bootstrap_servers='localhost:9092', group_id='consumer_group_1')
    
    try:
        for msg in consumer:
            print('Consumer 1 - Received message:', msg.value.decode('utf-8'))
    except KeyboardInterrupt:
        pass
    finally:
        consumer.close()

if __name__ == '__main__':
    topic = 'amazon_data_topic'  # Kafka topic to consume data from
    consume_data(topic)
