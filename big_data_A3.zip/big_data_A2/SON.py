class SON:
    def __init__(self, min_support, window_size):
        self.min_support = min_support
        self.itemsets = defaultdict(int)
        self.window_size = window_size
        self.window = []

    def _generate_candidates(self, transactions, k):
        candidates = defaultdict(int)
        for transaction in transactions:
            for candidate in combinations(transaction, k):
                candidates[frozenset(candidate)] += 1
        return candidates

    def _prune_candidates(self, candidates):
        pruned_candidates = {itemset: support for itemset, support in candidates.items() if support >= self.min_support}
        return pruned_candidates

    def _get_local_frequent_itemsets(self, transactions, k):
        candidates = self._generate_candidates(transactions, k)
        frequent_itemsets = self._prune_candidates(candidates)
        return frequent_itemsets

    def fit(self, transactions):
        self.window.extend(transactions)
        if len(self.window) >= self.window_size:
            frequent_itemsets = self._get_local_frequent_itemsets(self.window, 1)
            for k in range(2, len(self.window[0]) + 1):
                candidates = self._generate_candidates(self.window, k)
                frequent_itemsets.update(self._prune_candidates(candidates))
            for itemset, support in frequent_itemsets.items():
                self.itemsets[itemset] += support
            # Print real-time insights
            print("Frequent Itemsets (Window):")
            for itemset, support in frequent_itemsets.items():
                print(itemset, ":", support)
            # Shift window
            self.window = self.window[int(self.window_size / 2):]

def consume_transactions_from_kafka(consumer):
    for message in consumer:
        transaction = json.loads(message.value)
        yield transaction

if __name__ == "__main__":
    # Kafka consumer setup
    bootstrap_servers = 'localhost:9092'
    topic = 'amazon_data_topic'
    consumer = KafkaConsumer(topic,
                             bootstrap_servers=bootstrap_servers,
                             value_deserializer=lambda x: json.loads(x.decode('utf-8')))

    # Initialize SON algorithm with minimum support and window size
    min_support = 2
    window_size = 1000  # Adjust as needed
    son = SON(min_support=min_support, window_size=window_size)

    # Process data using SON algorithm with sliding window
    for transaction in consume_transactions_from_kafka(consumer):
        son.fit([transaction])
