import itertools

def generate_candidate_itemsets(itemsets, k):
    candidates = []
    # Generate combinations of size k
    for subset in itertools.combinations(itemsets, k):
        candidates.append(subset)
    return candidates

def generate_item_pairs(transaction):
    pairs = []
    for pair in itertools.combinations(transaction, 2):
        pairs.append(pair)
    return pairs

def generate_frequent_itemsets_with_pcy(transactions, min_support):
    single_item_counts = {}
    pair_counts = {}
    frequent_itemsets = []

    # Count occurrences of single items and pairs
    for transaction in transactions:
        # Increment count for each single item
        for item in transaction:
            single_item_counts[item] = single_item_counts.get(item, 0) + 1
        # Increment count for each pair of items
        pairs = generate_item_pairs(transaction)
        for pair in pairs:
            pair_counts[pair] = pair_counts.get(pair, 0) + 1

    # Output frequent single items
    frequent_single_items = [item for item, count in single_item_counts.items() if count >= min_support]

    # Output frequent pairs
    frequent_pairs = [pair for pair, count in pair_counts.items() if count >= min_support]

    # Generate candidate itemsets iteratively
    k = 3  # Start with triples
    while True:
        candidate_itemsets = generate_candidate_itemsets(frequent_single_items, k)
        if not candidate_itemsets:
            break

        hash_table = {}
        for candidate in candidate_itemsets:
            hash_table[candidate] = 0

        for transaction in transactions:
            pairs = generate_item_pairs(transaction)
            for pair in pairs:
                if pair in hash_table:
                    hash_table[pair] += 1

        for itemset, count in hash_table.items():
            if count >= min_support:
                frequent_itemsets.append(itemset)

        k += 1

    return frequent_itemsets
