import itertools

def generate_candidate_itemsets(itemsets, k):
    candidates = []
    # Generate combinations of size k
    for subset in itertools.combinations(itemsets, k):
        candidates.append(subset)
    return candidates

def generate_frequent_itemsets(transactions, min_support):
    item_counts = {}
    frequent_itemsets = []

    # Count occurrences of each item
    for transaction in transactions:
        for item in transaction:
            item_counts[item] = item_counts.get(item, 0) + 1

    # Output frequent itemsets of size 1
    for item, count in item_counts.items():
        if count >= min_support:
            frequent_itemsets.append([item])

    # Generate frequent itemsets iteratively
    k = 2
    while True:
        candidate_itemsets = generate_candidate_itemsets(frequent_itemsets, k)
        if not candidate_itemsets:
            break

        item_counts = {}
        for transaction in transactions:
            for candidate in candidate_itemsets:
                if all(item in transaction for item in candidate):
                    item_counts[tuple(candidate)] = item_counts.get(tuple(candidate), 0) + 1

        frequent_itemsets = []
        for itemset, count in item_counts.items():
            if count >= min_support:
                frequent_itemsets.append(list(itemset))

        k += 1

    return frequent_itemsets

