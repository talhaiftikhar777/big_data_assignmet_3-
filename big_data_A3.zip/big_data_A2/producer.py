
from kafka import KafkaProducer
import json
import time

def delivery_report(err, msg):
    if err is not None:
        print('Message delivery failed:', err)
    else:
        print('Message delivered to {} [{}]'.format(msg.topic(), msg.partition()))

def produce_data_from_file(file_path, topic, batch_size=1000):
    producer = KafkaProducer(bootstrap_servers='localhost:9092',
                             value_serializer=lambda x: json.dumps(x).encode('utf-8'))

    with open(file_path, 'r') as file:
        data = file.readlines()

    batch = []
    for item in data:
        batch.append(item.strip())
        if len(batch) >= batch_size:
            for msg in batch:
                producer.send(topic, value=msg, callback=delivery_report)
                print('Data sent to Kafka:', msg)
            producer.flush()
            batch = []
            time.sleep(0.1)  # Adjust the sleep time based on the desired throughput

    # Send remaining messages
    if batch:
        for msg in batch:
            producer.send(topic, value=msg, callback=delivery_report)
            print('Data sent to Kafka:', msg)
        producer.flush()

    producer.close()

if __name__ == '__main__':
    file_path = 'path/to/your/preprocessed_data.txt'  # Specify the path to your preprocessed data file
    topic = 'amazon_data_topic'  # Kafka topic to produce data to
    produce_data_from_file(file_path, topic)












# from kafka import KafkaProducer
# import json
# import time

# def delivery_report(err, msg):
#     if err is not None:
#         print('Message delivery failed:', err)
#     else:
#         print('Message delivered to {} [{}]'.format(msg.topic(), msg.partition()))

# def produce_data_from_file(file_path, topic):
#     producer = KafkaProducer(bootstrap_servers='localhost:9092',
#                              value_serializer=lambda x: json.dumps(x).encode('utf-8'))

#     with open(file_path, 'r') as file:
#         data = file.readlines()

#     for item in data:
#         producer.send(topic, value=item.strip(), callback=delivery_report)
#         print('Data sent to Kafka:', item.strip())
#         producer.flush()
#         time.sleep(1)  # Simulate real-time streaming

#     producer.close()

# if __name__ == '__main__':
#     file_path = 'path/to/your/preprocessed_data.txt'  # Specify the path to your preprocessed data file
#     topic = 'amazon_data_topic'  # Kafka topic to produce data to
#     produce_data_from_file(file_path, topic)
