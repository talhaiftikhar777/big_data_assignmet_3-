
from kafka import KafkaConsumer

def consume_data(topic):
    consumer = KafkaConsumer(topic, bootstrap_servers='localhost:9092', group_id='consumer_group_2',
                             enable_auto_commit=False, auto_offset_reset='earliest')

    try:
        for msg in consumer:
            print('Consumer 2 - Received message:', msg.value.decode('utf-8'))
            consumer.commit()  # Commit the offset after processing each message
    except KeyboardInterrupt:
        pass
    finally:
        consumer.close()

if __name__ == '__main__':
    topic = 'amazon_data_topic'  # Kafka topic to consume data from
    consume_data(topic)










# from kafka import KafkaConsumer

# def consume_data(topic):
#     consumer = KafkaConsumer(topic, bootstrap_servers='localhost:9092', group_id='consumer_group_3')
    
#     try:
#         for msg in consumer:
#             print('Consumer 3 - Received message:', msg.value.decode('utf-8'))
#     except KeyboardInterrupt:
#         pass
#     finally:
#         consumer.close()

# if __name__ == '__main__':
#     topic = 'amazon_data_topic'  # Kafka topic to consume data from
#     consume_data(topic)
